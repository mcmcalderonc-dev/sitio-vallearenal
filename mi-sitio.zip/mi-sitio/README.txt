Mi Sitio - versión lista para subir
----------------------------------
Archivos incluidos:
- index.html, about.html, services.html, contact.html
- css/styles.css
- js/main.js
- images/slider1.jpg, slider2.jpg, slider3.jpg

Nota:
- Reemplaza 'https://formspree.io/f/tu-id' en contact.html por tu endpoint de Formspree o el servicio que prefieras.
- Cambia textos e imágenes por los tuyos antes de publicar.
